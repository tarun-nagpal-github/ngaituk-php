<?php
  include "../config.php";   
$json = file_get_contents('php://input');
$data = json_decode($json);
 

if(
    !empty($data->name) &&
    !empty($data->address) 
) 
 {
$query = "INSERT INTO contractors (c_name, c_add)
               VALUES ('$data->name','$data->address')";
$myArray = array(); 
 

if ($result = $db->query($query)) { 
    $myArray[] = $result;
    echo json_encode($myArray);
    http_response_code(200);
}  else {
  http_response_code(400);
}
}
$db->close();